# Super Netherite & Piston Fusion (Fabric 1.20.1)

Susunan: sticky piston kiri dan kanan saling berhadapan, taruh block/mob di depan masing-masing piston, lalu tekan lever.

- 2 Netherite Block (tepat 2 sel di antara dua kepala piston) -> 1 **Super Netherite**
- Kuda + Sapi -> **Kuda Sapi** (kuda jinak berpelana, 60 HP, regenerasi)
- Domba + Ayam -> **Domba Ayam** (domba kuning, slow falling, lompat tinggi)
- Ocelot + Kucing -> **Kucing Ocelot** (kucing jinak, cepat, serangan 6)

## Build
Upload folder ini ke GitHub, tab Actions -> Build -> unduh artifact `supernetherite-jar`.
Atau lokal: `gradle build` (Gradle 8.5, Java 17), jar ada di `build/libs/`.
