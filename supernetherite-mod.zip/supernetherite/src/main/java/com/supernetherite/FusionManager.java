package com.supernetherite;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Mendeteksi dua sticky piston yang saling berhadapan dan sama-sama sudah memanjang,
 * lalu menggabungkan isi di antara kedua kepala piston.
 */
public final class FusionManager {
    /** Piston butuh 2 tick untuk memanjang; kita tunggu sedikit lebih lama supaya semuanya sudah diam. */
    private static final int DELAY_TICKS = 6;
    private static final int MAX_DISTANCE = 8;

    private static final List<Pending> PENDING = new ArrayList<>();

    private static final class Pending {
        final ServerWorld world;
        final BlockPos pos;
        final Direction dir;
        int ticks = DELAY_TICKS;

        Pending(ServerWorld world, BlockPos pos, Direction dir) {
            this.world = world;
            this.pos = pos;
            this.dir = dir;
        }
    }

    private record MobRecipe(EntityType<?> a, EntityType<?> b, FusedMobs.Spawner spawner) {
    }

    private static final List<MobRecipe> MOB_RECIPES = List.of(
            new MobRecipe(EntityType.HORSE, EntityType.COW, FusedMobs::spawnHorseCow),
            new MobRecipe(EntityType.SHEEP, EntityType.CHICKEN, FusedMobs::spawnSheepChicken),
            new MobRecipe(EntityType.OCELOT, EntityType.CAT, FusedMobs::spawnOcelotCat)
    );

    private FusionManager() {
    }

    public static void schedule(ServerWorld world, BlockPos pos, Direction dir) {
        BlockPos immutable = pos.toImmutable();
        for (Pending p : PENDING) {
            if (p.world == world && p.pos.equals(immutable)) {
                p.ticks = DELAY_TICKS;
                return;
            }
        }
        PENDING.add(new Pending(world, immutable, dir));
    }

    public static void tick(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        Iterator<Pending> it = PENDING.iterator();
        List<Pending> due = new ArrayList<>();
        while (it.hasNext()) {
            Pending p = it.next();
            if (--p.ticks <= 0) {
                due.add(p);
                it.remove();
            }
        }
        for (Pending p : due) {
            process(p.world, p.pos, p.dir);
        }
    }

    private static void process(ServerWorld world, BlockPos pos, Direction dir) {
        BlockState self = world.getBlockState(pos);
        if (!self.isOf(Blocks.STICKY_PISTON) || !self.get(Properties.EXTENDED)
                || self.get(Properties.FACING) != dir) {
            return;
        }

        // Cari kepala piston lawan yang menghadap ke arah kita.
        int j = -1;
        for (int i = 2; i <= MAX_DISTANCE; i++) {
            BlockState s = world.getBlockState(pos.offset(dir, i));
            if (s.isOf(Blocks.PISTON_HEAD) && s.get(Properties.FACING) == dir.getOpposite()) {
                j = i;
                break;
            }
        }
        if (j < 0) {
            return;
        }

        int gap = j - 2; // jumlah sel kosong/isi di antara dua kepala piston
        if (gap < 1) {
            return;
        }

        // 1) Fusi block: dua netherite block bersebelahan di antara dua kepala piston.
        if (gap == 2) {
            BlockPos first = pos.offset(dir, 2);
            BlockPos second = pos.offset(dir, 3);
            if (world.getBlockState(first).isOf(Blocks.NETHERITE_BLOCK)
                    && world.getBlockState(second).isOf(Blocks.NETHERITE_BLOCK)) {
                world.setBlockState(second, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                world.setBlockState(first, SuperNetheriteMod.SUPER_NETHERITE_BLOCK.getDefaultState(), Block.NOTIFY_ALL);
                double cx = first.getX() + 0.5 + (dir.getOffsetX() * 0.5);
                double cy = first.getY() + 0.5 + (dir.getOffsetY() * 0.5);
                double cz = first.getZ() + 0.5 + (dir.getOffsetZ() * 0.5);
                effects(world, cx, cy, cz);
                return;
            }
        }

        // 2) Fusi mob: dua mob di dalam ruang antara dua kepala piston.
        Box box = new Box(pos.offset(dir, 2)).union(new Box(pos.offset(dir, j - 1)))
                .expand(0.3, 0.2, 0.3).stretch(0.0, 1.0, 0.0);
        List<LivingEntity> mobs = world.getEntitiesByClass(LivingEntity.class, box,
                e -> e.isAlive() && !(e instanceof PlayerEntity));
        if (mobs.size() < 2) {
            return;
        }

        for (MobRecipe recipe : MOB_RECIPES) {
            LivingEntity a = null;
            LivingEntity b = null;
            for (LivingEntity e : mobs) {
                if (a == null && e.getType() == recipe.a()) {
                    a = e;
                } else if (b == null && e.getType() == recipe.b()) {
                    b = e;
                }
            }
            if (a != null && b != null) {
                double x = (a.getX() + b.getX()) / 2.0;
                double y = Math.min(a.getY(), b.getY());
                double z = (a.getZ() + b.getZ()) / 2.0;
                float yaw = a.getYaw();
                PlayerEntity owner = world.getClosestPlayer(x, y, z, 24.0, false);
                a.discard();
                b.discard();
                recipe.spawner().spawn(world, x, y, z, yaw, owner);
                effects(world, x, y + 1.0, z);
                return;
            }
        }
    }

    private static void effects(ServerWorld world, double x, double y, double z) {
        world.spawnParticles(ParticleTypes.END_ROD, x, y, z, 40, 0.5, 0.5, 0.5, 0.15);
        world.spawnParticles(ParticleTypes.PORTAL, x, y, z, 60, 0.6, 0.6, 0.6, 0.5);
        world.playSound(null, x, y, z, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 1.0f, 1.2f);
        world.playSound(null, x, y, z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.5f, 1.5f);
    }
}
